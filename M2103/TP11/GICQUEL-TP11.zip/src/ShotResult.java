package battle;

/**
* Enumeration of available shot result
*/
public enum ShotResult
{
	MISS,
	HIT,
	SUNK;
}