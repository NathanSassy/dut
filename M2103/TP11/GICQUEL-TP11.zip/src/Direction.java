package battle;

/**
* Enumeration of available directions
*/
public enum Direction
{
	HORIZONTAL,
	VERTICAL;
}