/**
* Generic interface to compare objects
*/
public interface Comparable<T>
{
	public int compareTo(T o);
}