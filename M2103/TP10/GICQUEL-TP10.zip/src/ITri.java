package tri;

/**
* This interface allows you to sort your object array
*/
public interface ITri
{
	public void trier();
}