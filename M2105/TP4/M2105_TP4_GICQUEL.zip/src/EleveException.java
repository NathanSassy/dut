package model;

public class EleveException extends Exception
{
	public EleveException(String erreur)
	{
		super(erreur);
	}
}