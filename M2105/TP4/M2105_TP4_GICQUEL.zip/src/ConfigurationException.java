package controller;

public class ConfigurationException extends Exception
{
	public ConfigurationException(String err)
	{
		super(err);
	}
}