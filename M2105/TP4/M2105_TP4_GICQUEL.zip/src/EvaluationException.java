package model;

public class EvaluationException extends Exception
{
	public EvaluationException(String erreur)
	{
		super(erreur);
	}
}